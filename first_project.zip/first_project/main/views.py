from django.shortcuts import render
from django.views.generic import TemplateView
# Create your views here.

#controller function
# def index(request):
# 	print(request.user.username)
# 	print(request.user.first_name)
# 	print(request.user.last_name)
# 	return render(request, 'home.html')

#controller class
class HomeView(TemplateView):
	template_name = 'index.html'

class DefaultPageView(TemplateView):
	template_name = 'default.html'

class DarkPageView(TemplateView):
	template_name = 'dark.html'
