from django.urls import path 
from .import views

app_name = 'main'

urlpatterns = [
	# path('',views.index , name='home' )
	path('',views.HomeView.as_view() , name='home' ),
	path('default/',views.DefaultPageView.as_view() , name='default' ),
	path('dark/',views.DarkPageView.as_view() , name='dark' ),
]
